/*
 * Bisection.cpp
 *
 *  Created on: Oct 15, 2016
 *      Author: user
 */

#include "Bisection.hpp"

#include <iostream>
#include <cmath>
#include <cstdlib>

real Bisection::find_root(int &nit) const {

  /* Your code goes here */

  return 0;
}
