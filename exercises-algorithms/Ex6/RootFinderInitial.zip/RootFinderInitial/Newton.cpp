/*
 * Newton.cpp
 *
 *  Created on: Oct 15, 2016
 *      Author: user
 */

#include "Newton.hpp"

real Newton::find_root(int &nit) const {

  /* Your code goes here */

  return 0;
}
