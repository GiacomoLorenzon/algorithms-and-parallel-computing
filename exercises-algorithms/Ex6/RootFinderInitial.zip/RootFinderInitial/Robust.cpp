/*
 * Robust.cpp
 *
 *  Created on: Oct 15, 2016
 *      Author: user
 */

#include "Robust.hpp"

real Robust::find_root(int &nit_bis, int &nit_newt) const {

  /* Your code goes here */

  return 0;
}


