//
// Created by luca on 02/11/21.
//

#ifndef EMPLOYEE__DEVELOPER_H
#define EMPLOYEE__DEVELOPER_H

#include "Employee.h"

class Developer : public Employee {
protected:
  const double wsh_rate = 8.0;
  unsigned int wsh_hours = 0;

public:
  Developer(std::string n, std::string s, unsigned int ID) :
      Employee(n, s, ID) {};

  void set_wsh_hours(unsigned int hours) { wsh_hours = hours; }
  double salary_cal() const override {
    double wsh_pay = (wsh_hours * wsh_rate);
    double w_pay = (work_hours - wsh_hours) * pay_rate;
    return wsh_pay + w_pay;
  }
};

#endif //EMPLOYEE__DEVELOPER_H
