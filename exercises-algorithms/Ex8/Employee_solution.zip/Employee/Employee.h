//
// Created by luca on 02/11/21.
//

#ifndef EMPLOYEE__EMPLOYEE_H
#define EMPLOYEE__EMPLOYEE_H

#include <string>
#include <iostream>

class Employee {
protected:
  std::string name;
  std::string surname;
  unsigned int employee_ID;
  const double pay_rate = 7.5;
  unsigned int work_hours = 0;

public:
  Employee(std::string n, std::string s, unsigned int ID) :
    name(n), surname(s), employee_ID(ID) {};

  void set_work_hours(unsigned int hours) {work_hours = hours;}

  void print() {
    std::cout << name << " " << surname << " " << employee_ID << std::endl;
  }

  virtual double salary_cal() const = 0;

};

#endif //EMPLOYEE__EMPLOYEE_H
