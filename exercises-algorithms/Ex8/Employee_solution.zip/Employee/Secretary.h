//
// Created by luca on 02/11/21.
//

#ifndef EMPLOYEE__SECRETARY_H
#define EMPLOYEE__SECRETARY_H

#include "Employee.h"

class Secretary : public Employee {
public:
  Secretary(std::string n, std::string s, unsigned int ID) :
      Employee(n, s, ID) {};

  double salary_cal() const override {return (work_hours * pay_rate);}
};


#endif //EMPLOYEE__SECRETARY_H
