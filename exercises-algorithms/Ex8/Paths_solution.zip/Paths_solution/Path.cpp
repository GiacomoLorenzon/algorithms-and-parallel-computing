#include "Path.h"

Path::Path(unsigned int l) : length(l) {}

Path::Path(Path& p) : length(p.length) {
  avgRating = p.avgRating;
}

unsigned Path::getPoints() {
  return (avgRating + 2) * length;
}

void Path::rate(unsigned int rating) {
  if (0 < rating && rating < 11) {
    avgRating = ((numOfReviews * avgRating) + rating) / (numOfReviews + 1);
    ++numOfReviews;
  } else {
    std::cout << "Rating out of bound!" << std::endl;
  }
}