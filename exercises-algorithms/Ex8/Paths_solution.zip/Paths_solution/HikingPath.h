#include "Path.h"

class HikingPath : public Path {
private:
    unsigned height = 0;

public:
    HikingPath(unsigned l, unsigned h);

    unsigned getPoints();

    void rate(unsigned rating) override;

    virtual ~HikingPath() {};
};