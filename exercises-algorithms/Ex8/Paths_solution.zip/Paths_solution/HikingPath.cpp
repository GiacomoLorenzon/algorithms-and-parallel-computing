#include "HikingPath.h"

HikingPath::HikingPath(unsigned int l, unsigned int h)  : Path(l), height(h) {}

unsigned int HikingPath::getPoints() {
  return 10 * length + height / 100;
}

void HikingPath::rate(unsigned int rating) {
  if (rating < 15) {
    avgRating = ((numOfReviews * avgRating) + rating) / (numOfReviews + 1);
    ++numOfReviews;
  } else {
    std::cout << "Rating out of bound!" << std::endl;
  }
}
