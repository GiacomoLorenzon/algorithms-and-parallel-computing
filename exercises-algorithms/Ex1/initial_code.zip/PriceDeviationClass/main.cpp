// Price deviation evaluation v1

#include <iostream>
#include <iomanip>

using std::cout;
using std::cin;
using std::endl;
using std::setw;


int main (void)
{
    // Your code goes here

    cout  << "Input price: ";


    // Your code goes here

    if (num != 0)
    {
        cout << endl << setw(20) << "Prices" << setw(40) << "Deviation from the mean" << endl;

        for (unsigned i = 0; i < num; ++i)
        {
            // Your code goes here
        }
    }

    return 0;
}