#include "DocumentStore.h"

DocumentStore::DocumentStore (std::size_t s):
    docs(s), docsDraft(DRAFT_SIZE), size(s),
    curr(0), currDraft(0)
{}

DocumentStore::DocumentStore (const DocumentStore& rhs):
    docs(rhs.docs), docsDraft(DRAFT_SIZE), size(rhs.size),
    curr(rhs.curr), currDraft(0)
{}

DocumentStore&
DocumentStore::operator= (const DocumentStore& rhs)
{
    /* DocumentStore s1
     *  s1.docs = [A, B, C]         s1.curr = 3
     *  s1.docsDraft = [dA, dB]     s1.currDraft = 2
     *
     * DocumentStore s2
     *  s2.docs = [D, E]            s2.curr = 2
     *  s2.docsDraft = [dD, dE]     s2.currDraft = 2
     *
     * s2 = s1
     *  s2.docs = [A, B, C]         s2.curr = 3
     *  s2.docsDraft = [dD, dE]     s2.currDraft = 0
     * */

    docs = rhs.docs;
    size = rhs.size;
    curr = rhs.curr;
    // docsDraft = std::vector<Document>(DRAFT_SIZE);
    currDraft = 0;
    return *this;
}

void DocumentStore::addDocument (const Document& doc)
{
    /*
     * docs = [_, _, _, _, _]
     * operator[]
     * */

    if (curr < size)
        docs[curr++] = doc;
}

void DocumentStore::saveAsDraft (const Document& draft)
{
    if (currDraft < DRAFT_SIZE)
        docsDraft[currDraft++] = draft;
}

void DocumentStore::print () const
{
    std::cout << "List of Documents:" << std::endl;
    for (std::size_t j = 0; j < curr; ++j)
        docs[j].print();

    std::cout << "List of Drafts:" << std::endl;
    for (std::size_t j = 0; j < currDraft; ++j)
        docsDraft[j].print();
}
