#include "Centroid.h"

void
Centroid::update_coords (/* Your code goes here */ )
{
    /* Your code goes here */
}
