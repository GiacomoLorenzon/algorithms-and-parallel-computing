#include "Centroid.h"

void
Centroid::update_coords (const std::vector<Point *> & ps) //O(n*p)
{
    std::vector<double> new_coords(x.size(), 0); //O(p)
    // compute the mean starting from std::vector<Point *>

    //O(n *p)
    for (size_t i =0; i < ps.size(); ++i ){
        for (size_t j =0; j < new_coords.size(); ++j) //O(p)
            new_coords[j]+= ps[i]->get_coord(j);

    }
    //O(p)
    for (size_t j =0; j < new_coords.size(); ++j)
        new_coords[j]/= ps.size();

    //x = new_coords; //O(p)

    //x.swap(new_coords);

    swap(x,new_coords); //O(1)

}
