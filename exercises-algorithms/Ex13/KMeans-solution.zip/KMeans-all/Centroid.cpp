#include "Centroid.h"

void
Centroid::update_coords (std::vector<Point *> const & ps)
{
  std::vector<double> new_coords(x.size(),0);

  for (std::size_t i = 0; i < ps.size (); ++i)
    {
      for (std::size_t j = 0; j < x.size (); ++j)
        //new_coords[j] += ps[i] -> x[j];  Try what happens with this!
        new_coords[j] += ps[i] -> get_coord (j);
    }

  for (std::size_t j = 0; j < x.size (); ++j)
    new_coords[j] /= ps.size ();
  x.swap (new_coords);
}
