//
// Created by Danilo Ardagna on 2019-08-23.
//

#include "Library.h"

int Library::find(const string &author, const string &title) const{
    int return_index = -1;
    bool book_found = false;
    for (size_t i =0; i< books.size() && !book_found; ++i)
        if (books[i].equal_to(author,title)){
            book_found = true;
            return_index = i;
        }

    return return_index;

}

int Library::findAvailableBook(const string &author, const string &title) const{
    int return_index = -1;
    bool book_found = false;
    for (size_t i =0; i< books.size() && !book_found; ++i)
        if (books[i].equal_to(author,title) && books[i].isAvailable()){
            book_found = true;
            return_index = i;
        }

    return return_index;
}

void Library::addBook(const Book &book) {
    books.push_back(book);
}

int Library::rentBook(const string &author, const string &title) {

    int index = findAvailableBook(author,title);
    if (index == -1){
        cerr << "Book not available" << endl;
        return -1;
    }

    else{
        books[index].setAvailable(false);
        return books[index].getCode();
    }

}

bool Library::returnBook(unsigned code) {

    bool book_found = false;
    size_t i;
    for (i =0; i< books.size() && !book_found; ++i)
        if (books[i].getCode() == code && !books[i].isAvailable())
            book_found = true;

    if (book_found){
        books[i-1].setAvailable(true);
        return true;
    }
    else{
        cerr << "Book already in store" << endl;
        return false;
    }



}

void Library::print() const {

    for (size_t i = 0; i < books.size(); ++i) {
        books[i].print();
    }

}

void Library::printOldest() const {
    size_t oldest = 0;

    for (size_t i=1; i< books.size(); ++i)
        if(books[i].getYear()<books[oldest].getYear())
            oldest = i;

    books[oldest].print();
}
