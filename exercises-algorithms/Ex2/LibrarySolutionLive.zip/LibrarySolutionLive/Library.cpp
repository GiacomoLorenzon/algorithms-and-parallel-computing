//
// Created by Danilo Ardagna on 2019-09-28.
//

#include "Library.h"


/* YOUR CODE GOES HERE */
int Library::find(const string &author, const string &title) const {
    int return_index = -1;
    bool book_found = false;

    for (size_t i = 0; i < books.size() && !book_found ; ++i ){
        if (books[i].equal_to(author,title)){
            return_index = i;
            book_found = true;
        }

    }

    return return_index;
}

int Library::findAvailableBook(const string &author, const string &title) const {
    int return_index = -1;
    bool book_found = false;

    for (size_t i = 0; i < books.size() && !book_found ; ++i ){
        if (books[i].equal_to(author,title) && books[i].isAvailable() ){
            return_index = i;
            book_found = true;
        }

    }

    return return_index;
}

void Library::addBook(const Book &book) {
    books.push_back(book);
}

int Library::rentBook(const string &author, const string &title) {
    int index = findAvailableBook(author,title);

    if(index == -1){
        cerr << "THe book is not available, sorry!" << endl;
        return  -1;
    }
    else{
       books[index].setAvailable(false);
       return books[index].getCode();
    }

}

bool Library::returnBook(unsigned int code) {

    bool book_found = false;

    for (size_t i = 0; i < books.size() && !book_found ; ++i ){
        if (books[i].getCode() == code){
            if (!books[i].isAvailable()){
                book_found = true;
                books[i].setAvailable(true);
            }

        }
    if (!book_found)
        cerr << "Book already available or not found";
    }

    return book_found;
}

void Library::print() const {
    for (size_t i = 0; i < books.size() ; ++i) {
        books[i].print();

    }
}

void Library::printOldest() const {

}
