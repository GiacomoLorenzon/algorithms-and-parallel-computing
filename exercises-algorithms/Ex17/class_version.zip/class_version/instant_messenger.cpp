//
// Created by Federica Filippini on 23/11/2020.
//

#include "instant_messenger.h"

namespace im
{
    void Messenger::send (key_type timestamp,
                          const mapped_type& text)
    {
        m_data[timestamp] = text;   // O(log N)
    }

    std::list<Messenger::mapped_type>
    Messenger::receive (key_type timestamp) const
    {
        std::list<mapped_type> result;

        // lower_bound --> O(log N)
        for (container_type::const_iterator it = m_data.lower_bound(timestamp);
             it != m_data.cend(); ++it)
        {
            result.push_back(it->second);    // vector --> O(L)
                                             // list --> O(1)
        }   // loop --> O(L)

        // O(log N + L)

        /*
        for (container_type::const_reverse_iterator it = m_data.rbegin();
             it != m_data.rend() && it->first > timestamp; ++it)
        {
            result.push_front(it->second);
        }
         */

        return result;
    }

    std::list<Messenger::mapped_type>
    Messenger::search (const std::string& word) const
    {
        std::list<mapped_type> result;

        for (const value_type& pair : m_data)       // O(N)
        {
            const mapped_type& message = pair.second;

            // I come home at 5 pm
            //
            if (message.find(word) != std::string::npos)    // find --> O(MW)
                result.push_back(message);
        }

        // O(NMW)
        // M << N --> O(N)

        return result;
    }
}