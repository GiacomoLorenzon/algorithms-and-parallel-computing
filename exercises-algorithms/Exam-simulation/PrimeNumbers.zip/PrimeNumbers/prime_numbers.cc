#include <iostream>
#include <vector>
#include <mpi.h>


// return the vector of prime numbers in the given range
std::vector<unsigned> get_prime_numbers (unsigned, unsigned);

// return true if the given number is prime
bool is_prime (unsigned);


int main (int argc, char *argv[])
{
  // init
  MPI_Init(&argc, &argv);

  // initialize rank and size
  int rank, size;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // read parameters from command-line
  unsigned min = std::stoi(argv[1]);
  unsigned max = std::stoi(argv[2]);

  // get the vector of prime numbers
  std::vector<unsigned> prime_numbers = get_prime_numbers(min, max);

  // rank 0 prints the prime numbers
  if (rank == 0)
  {
    std::cout << "prime numbers between " << min << " and " << max 
              << " are:" << std::endl;
    for (unsigned n : prime_numbers)
      std::cout << n << " ";
    std::cout << std::endl;
  }

  // finalize
  MPI_Finalize();

  return 0;
}


std::vector<unsigned> get_prime_numbers (unsigned min, unsigned max)
{
  // initialize rank and size
  int rank, size;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // initialize vector of prime numbers in each rank
  std::vector<unsigned> my_prime_numbers;

  // loop over the given range (cyclic partitioning)
  for (unsigned n = min + rank; n <= max; n += size)
  {
    // if the current number is prime, insert it in the corresponding vector
    if (is_prime(n))
      my_prime_numbers.push_back(n);
  }

  // collect all partial results in a single vector
  std::vector<unsigned> all_prime_numbers;
  for (int r = 0; r < size; ++r)
  {
    if (r == rank)
    {
      // get and communicate how many prime numbers the current core has found
      unsigned n_primes = my_prime_numbers.size();
      MPI_Bcast(&n_primes, 1, MPI_UNSIGNED, rank, MPI_COMM_WORLD);

      // insert the new values at the end of the vector of prime numbers and
      // communicate them to all the other cores
      unsigned old_n_primes = all_prime_numbers.size();
      all_prime_numbers.insert(all_prime_numbers.end(), 
                               my_prime_numbers.cbegin(), 
                               my_prime_numbers.cend());

      MPI_Bcast(all_prime_numbers.data() + old_n_primes, n_primes, 
                MPI_UNSIGNED, rank, MPI_COMM_WORLD);
    }
    else
    {
      // get the new number of primes
      unsigned n_primes;
      MPI_Bcast(&n_primes, 1, MPI_UNSIGNED, r, MPI_COMM_WORLD);

      // resize the vector of prime numbers and get the new values
      unsigned old_n_primes = all_prime_numbers.size();
      all_prime_numbers.resize(old_n_primes + n_primes);
      MPI_Bcast(all_prime_numbers.data() + old_n_primes, n_primes, 
                MPI_UNSIGNED, r, MPI_COMM_WORLD);
    }
  }

  return all_prime_numbers;
}


bool is_prime (unsigned n)
{
  bool prime = true;

  // if n can be divided by any number in [2, n-1], it is not prime
  for (unsigned j = 2; j < n && prime; ++j)
  {
    if (n%j == 0)
    {
      prime = false;
    }
  }

  return prime;
}

