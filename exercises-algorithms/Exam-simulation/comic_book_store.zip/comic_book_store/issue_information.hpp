#ifndef ISSUE_INFORMATION_HPP
#define ISSUE_INFORMATION_HPP
#include <string>

class IssueInformation
{
   private:
      ///Number of available copies
      unsigned int available_copies;

      ///Issue date
      std::string issue_date;

   public:
      ///Constructor
      IssueInformation(unsigned int initially_available_copies, const std::string & _issue_date) :
         available_copies(initially_available_copies),
         issue_date(_issue_date)
      {}

      ///Buy a copy
      void BuyIssue()
      {
         available_copies--;
      }

      ///Check for availability
      bool CheckAvailability() const
      {
         return available_copies != 0;
      }
};
#endif
