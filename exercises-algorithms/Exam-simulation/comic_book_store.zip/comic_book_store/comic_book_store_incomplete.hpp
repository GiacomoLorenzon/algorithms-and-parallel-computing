class ComicBookStore
{
   private:
      /// Data structure used to store necessary information

   public:
      /// Add a new comic book series
      void AddComicBookSeries(const std::string & title, double price_per_issue, unsigned int issues_number);

      /// Add to warehouse
      void AddToWareHouse(const std::string & title, const std::string & date, unsigned int issue_number, unsigned int quantity);

      /// Buy a single issue
      double BuyIssue(const std::string & title, unsigned int issue_number);

      /// Buy a whole series
      double BuySeries(const std::string & title);

      /// Return the price of an issue of a comic series
      double GetPrice(const std::string & title) const;

      /// Return the n series with highest price for issue
      std::list<SingleComicBookSeries> GetMostExpensive(unsigned int n) const;

       Check the availability of an issue
      bool CheckAvailability(const std::string & title, unsigned int issue_number) const;
};
