#include <iostream>

#include "comic_book_store.hpp"

#define RADIOACTIVE_MAN "Radioactive Man"
#define COLLECTION "The Radioactive Man Collection"
#define SPIDER "The Amazing Spider-Man"

int main()
{
   ComicBookStore comic_book_store("The Android's Dungeon & Baseball Card Shop");
   comic_book_store.AddComicBookSeries(RADIOACTIVE_MAN, 2.25, 7);
   comic_book_store.AddComicBookSeries(COLLECTION, 9.99, 7);
   comic_book_store.AddComicBookSeries(SPIDER, 7.99, 700);
   for(int i = 1; i <= 7; i++)
      comic_book_store.AddToWareHouse(RADIOACTIVE_MAN, "xx-xx-xxxx", i, 3);
   for(int i = 1; i <= 7; i++)
      comic_book_store.AddToWareHouse(COLLECTION, "xx-xx-xxxx", i, 3);
   for(int i = 0; i < 5; i++)
      std::cout << "Buying Radioactive Man 7: " << comic_book_store.BuyIssue(RADIOACTIVE_MAN, 7) << "$" << std::endl;
   std::cout << "Buying whole series of Radiactive Man: " << comic_book_store.BuySeries(RADIOACTIVE_MAN) << "$" << std::endl;
   std::cout << "Buying whole series of The Radioactive Man Collection: " << comic_book_store.BuySeries(COLLECTION) << "$" << std::endl;
   std::cout << "Get the most expensive comic book " << std::endl;
   const auto most_expensive_comic_book_series = comic_book_store.GetMostExpensive(2);
   for(const auto most_expensive_single_comic_book_series : most_expensive_comic_book_series)
      std::cout << most_expensive_single_comic_book_series.CGetTitle() << " " << most_expensive_single_comic_book_series.CGetPricePerIssue() << "$" << std::endl;

   return 0;
}
