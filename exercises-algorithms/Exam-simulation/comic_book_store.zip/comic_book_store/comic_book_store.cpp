#include <iostream>
#include <utility>

#include "comic_book_store.hpp"

ComicBookStore::ComicBookStore(const std::string & _name) :
   name(_name)
{}

void ComicBookStore::AddToWareHouse(const std::string & title, const std::string & date, unsigned int issue_number, unsigned int quantity)
{
   warehouse.at(title).insert(std::pair<unsigned int, IssueInformation>(issue_number, IssueInformation(quantity, date)));
}

double ComicBookStore::BuyIssue(const std::string & title, unsigned int issue_number)
{
   if(CheckAvailability(title, issue_number))
   {
      warehouse.at(title).at(issue_number).BuyIssue();
      return GetPrice(title);
   }
   else
   {
      return 0.0;
   }
}

double ComicBookStore::GetPrice(const std::string & title) const
{
   return comic_book_series.at(title).CGetPricePerIssue();
}

double ComicBookStore::BuySeries(const std::string & title)
{
   const auto issues_number = comic_book_series.at(title).CGetIssuesNumber();
   for(unsigned int i = 1; i <= issues_number; i++)
      if(not CheckAvailability(title, i))
         return 0.0;
   auto & availability = warehouse.at(title);
   for(unsigned int i = 1; i <= issues_number; i++)
      availability.at(i).BuyIssue();
   return issues_number * GetPrice(title);
}

std::list<SingleComicBookSeries> ComicBookStore::GetMostExpensive(unsigned int n) const
{
   std::list<SingleComicBookSeries> ret_value;
   for(auto single_comic_book_series = sorted_comic_series.crbegin(); single_comic_book_series != sorted_comic_series.crend() and ret_value.size() < n; single_comic_book_series++)
      ret_value.push_back(*single_comic_book_series);
   return ret_value;
}

void ComicBookStore::AddComicBookSeries(const std::string & title, double price_per_issue, unsigned int issues_number)
{
   SingleComicBookSeries single_comic_book_series(title, issues_number, price_per_issue);
   sorted_comic_series.insert(single_comic_book_series);
   comic_book_series.insert(std::pair<std::string, SingleComicBookSeries>(title, single_comic_book_series));
   warehouse[title];
}

bool ComicBookStore::CheckAvailability(const std::string & title, unsigned int issue_number) const
{
   return warehouse.at(title).find(issue_number) != warehouse.at(title).end() and warehouse.at(title).at(issue_number).CheckAvailability();
}
