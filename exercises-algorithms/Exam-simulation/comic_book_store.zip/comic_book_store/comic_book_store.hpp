#ifndef COMIC_BOOK_STORE_HPP
#define COMIC_BOOK_STORE_HPP

#include <string>

#include <list>
#include <unordered_map>
#include <set>

#include "single_comic_book_series.hpp"
#include "issue_information.hpp"

class ComicBookStore
{
   private:
      ///The content of the warehouse; first key is the title, second key is the issue number
      std::unordered_map<std::string, std::unordered_map<unsigned int, IssueInformation> > warehouse;
      std::unordered_map<std::string, SingleComicBookSeries> comic_book_series;
      std::set<SingleComicBookSeries> sorted_comic_series;

      ///The name of the shop
      std::string name;

   public:
      /**
       * Constructor
       */
      explicit ComicBookStore(const std::string & name);

      /**
       * Add a new comic book series
       */
      void AddComicBookSeries(const std::string & title, double price_per_issue, unsigned int issues_number);

      /**
       * Add to warehouse
       */
      void AddToWareHouse(const std::string & title, const std::string & date, unsigned int issue_number, unsigned int quantity);

      /**
       * Buy a single issue
       * @return the price
       */
      double BuyIssue(const std::string & title, unsigned int issue_number);

      /**
       * Buy a whole series
       * @return the cost
       */
      double BuySeries(const std::string & title);

      /**
       * Return the price of an issue of a comic series
       */
      double GetPrice(const std::string & title) const;

      /**
       * Return the n series with highest price for issue
       */
      std::list<SingleComicBookSeries> GetMostExpensive(unsigned int n) const;

      /**
       * Check the availability of an issue
       */
      bool CheckAvailability(const std::string & title, unsigned int issue_number) const;
};

#endif
