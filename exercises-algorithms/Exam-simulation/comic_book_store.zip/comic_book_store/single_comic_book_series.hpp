#ifndef SINGLE_COMIC_BOOK_SERIES_HPP
#define SINGLE_COMIC_BOOK_SERIES_HPP

#include <string>
class SingleComicBookSeries
{
   private:
      ///The title of the comic book series
      const std::string title;

      ///The number of issues up to now
      const unsigned int issues_number;

      ///The price of each issue
      const double price_per_issue;

   public:
      /// Constructor
      explicit SingleComicBookSeries(const std::string & _title, unsigned int _issues_number, double _price_per_issue):
         title(_title),
         issues_number(_issues_number),
         price_per_issue(_price_per_issue)
     {}

      /**
       * Get the title
       */
      const std::string CGetTitle() const
      {
         return title;
      }

      /**
       * Get the number of issues
       */
      unsigned int CGetIssuesNumber() const
      {
         return issues_number;
      }

      /**
       * Get the price per issue
       */
      double CGetPricePerIssue() const
      {
         return price_per_issue;
      }
};

bool operator<(const SingleComicBookSeries & first, const SingleComicBookSeries & second);
#endif
