#include "single_comic_book_series.hpp"
bool operator<(const SingleComicBookSeries & first, const SingleComicBookSeries & second)
{
   const auto first_price = first.CGetPricePerIssue();
   const auto second_price = second.CGetPricePerIssue();
   return first_price < second_price or (first_price == second_price and first.CGetTitle() < second.CGetTitle());
}
