// grep.cc
#include <fstream>
#include <iostream>
#include <sstream>

#include <mpi.h>

#include "grep.hh"

namespace grep
{
  void search_string (const std::string & file_name,
                      const std::string & search_string,
                      lines_found & local_filtered_lines,
                      unsigned & local_lines_number)
  {
    int rank (0);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    const unsigned rk (rank);
    local_lines_number = 0;
    std::ostringstream file_name_builder;
    file_name_builder << file_name << '-' << rk;
    const std::string local_file_name = file_name_builder.str ();
    std::ifstream f_stream (local_file_name);

    // read input file line by line
    for (std::string line; std::getline (f_stream, line); )
      {
        //increment local number of lines
        ++local_lines_number;

        if (line.find (search_string) != std::string::npos)
          {
            local_filtered_lines.push_back ({local_lines_number, line});
          }
      }
  }

  void print_result (const lines_found & local_filtered_lines,
                     unsigned local_lines_number)
  {
    ...
  }
}
