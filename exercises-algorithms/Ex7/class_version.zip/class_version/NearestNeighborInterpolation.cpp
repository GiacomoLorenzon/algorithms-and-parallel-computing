#include "NearestNeighborInterpolation.h"

/* TO BE COMPLETED */

NearestNeighborInterpolation::NearestNeighborInterpolation (const std::vector<Point> & p):
        Interpolation(p) {}

double
NearestNeighborInterpolation::interpolate (double x) const
{
    double result(err_val);

    if (range_check(x))
    {
        std::vector<Point>::const_iterator previous = points.cbegin();
        std::vector<Point>::const_iterator current = previous +1;

        while(current != points.cend() && current->get_x() < x)
        {
            ++current;
            ++previous;
        }

        if (current != points.cend())
        {
            // compute y
            const double x1(previous->get_x());
            const double x2(current->get_x());

            const double first_distance = x - x1;
            const double second_distance = x2 - x;

            const bool first_closest = (first_distance < second_distance);

            result = first_closest ? previous->get_y() : current->get_y();
        }
    }

    return result;
}
