#include <iostream>

#include "LinearInterpolation.h"
#include "StepwiseInterpolation.h"
#include "NearestNeighborInterpolation.h"

double interp_function (const Interpolation& LI, double x);

int
main (void)
{
    std::vector<Point> points {
    Point (1.0, 0.0),
      Point (2.0, 3.0),
      Point (3.0, 1.0),
      Point (4.0, 2.0),
      Point (5.0, 4.0)
      };

    double x = 3.5;
    //std::cin >> x;

    LinearInterpolation LI(points);
    std::cout << LI.interpolate(x) << std::endl;
    //
    StepwiseInterpolation SI(points);
    std::cout << SI.interpolate(x) << std::endl;
    //
    NearestNeighborInterpolation NI(points);
    std::cout << NI.interpolate(x) << std::endl;

    // dynamic binding
    const Interpolation& method = SI;
    std::cout << method.interpolate(x) << std::endl;

    std::cout << std::endl;
    std::cout << interp_function(LI, x) << std::endl;
    std::cout << interp_function(SI, x) << std::endl;
    std::cout << interp_function(NI, x) << std::endl;

    Interpolation* intp = &LI;

    Interpolation i(points);
    NearestNeighborInterpolation* nnp = &i;
    NearestNeighborInterpolation& nnr = i;

    return 0;
}

double interp_function (const Interpolation& method, double x)
{
    return method.interpolate(x);
}
