#include "Interpolation.h"

Interpolation::Interpolation(const std::vector<Point>& p):
    points(p) {}

bool Interpolation::range_check (double x) const
{
    bool b1 = (x < points.front().get_x());
    // points.front() == points[0]
    bool b2 = (x > points.back().get_x());
    // points.back() == points[points.size() - 1]
    return !(b1 || b2);
}