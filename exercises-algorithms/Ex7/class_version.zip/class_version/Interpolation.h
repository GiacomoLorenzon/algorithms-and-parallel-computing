#ifndef INTERPOLATION_HH
#define INTERPOLATION_HH

#include <vector>
#include <limits>

#include "Point.h"

class Interpolation
{
   /* TO BE COMPLETED */
protected:
  std::vector<Point> points; // sorted_vector
  static constexpr double err_val = std::numeric_limits<double>::quiet_NaN();

  bool range_check (double) const;

public:
  Interpolation(const std::vector<Point>& p);

  virtual double interpolate (double) const = 0;

  virtual ~Interpolation() = default;
};

#endif // INTERPOLATION_HH
