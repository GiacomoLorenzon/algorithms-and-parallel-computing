#include "LinearInterpolation.h"

/* TO BE COMPLETED */

LinearInterpolation::LinearInterpolation (const std::vector<Point> & points)

double
LinearInterpolation::interpolate (double x) const
{
}
