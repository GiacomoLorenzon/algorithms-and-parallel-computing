#include "StepwiseInterpolation.h"

/* TO BE COMPLETED */

StepwiseInterpolation::StepwiseInterpolation (const std::vector<Point> & points)

double
StepwiseInterpolation::interpolate (double x) const
{
}
