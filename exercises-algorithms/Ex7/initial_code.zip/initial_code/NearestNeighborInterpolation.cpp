#include "NearestNeighborInterpolation.h"

/* TO BE COMPLETED */

NearestNeighborInterpolation::NearestNeighborInterpolation (const std::vector<Point> & points)

double
NearestNeighborInterpolation::interpolate (double x) const
{
}
