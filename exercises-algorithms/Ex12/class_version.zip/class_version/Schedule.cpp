//
// Created by Federica Filippini on 16/11/2020.
//

#include "Schedule.h"


void Schedule::validate()
{
    if (! order.empty())
    {
        order[0].set_start_time(order[0].get_submission_time());

        ScheduledJob previous = order[0];

        for (std::size_t j = 1; j < order.size(); ++j)
        {
            double start_time = std::max(previous.get_end_time(),
                                         order[j].get_submission_time());
            order[j].set_start_time(start_time);
            previous = order[j];
        }
    }
}


Schedule::size_type Schedule::size() const
{
    return order.size();
}


void Schedule::add (const std::shared_ptr<Job>& ptr)
{

    if (order.empty())
        order.push_back(ScheduledJob(ptr));
    else
    {
        ScheduledJob sj(ptr, order.back().get_end_time());
        order.push_back(sj);
    }
}

double Schedule::evaluate() const
{
    double tardiness = 0.0;

    for (std::size_t i = 0; i < order.size(); ++i)
        tardiness += order[i].evaluate();

    return tardiness;
}


void Schedule::print() const
{
    for (std::size_t i = 0; i < order.size(); ++i)
    {
        order[i].print();
        std::cout << std::endl;
    }
}
