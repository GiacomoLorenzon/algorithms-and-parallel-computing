//
// Created by Federica Filippini on 09/12/2020.
//

#include "callcenter.h"

void CallCenter::RegisterTaxi (const std::string& license_id)
{
    Taxi new_taxi(license_id);
    taxis.insert(std::pair<std::string, Taxi>(license_id, new_taxi));

    // station_available_taxis \subset available_taxis
    available_taxis.insert(license_id);

    if (new_taxi.CGetPosition() == station)
        station_available_taxis.insert(new_taxi);
}

Taxi CallCenter::Call (const Place& source, const Place& destination)
{
    // return the taxi (in available_taxis) which is closest to the source

    if (available_taxis.empty())
    {
        std::cerr << "No available taxis" << std::endl;
        return Taxi("nonexistent");
    }

    std::string closest_taxi_id = *(available_taxis.begin());
    float closest_distance = ComputeDistance(source,
                        taxis.at(closest_taxi_id).CGetPosition());

    // N: # of taxis      M: # of available taxis
    for (const std::string& taxi_id : available_taxis)              // O(M): loop
    {
        // check if the current taxi is the closest
        float current_distance = ComputeDistance(source,        // O(1): at (average case)
                taxis.at(taxi_id).CGetPosition());  // O(N): at (worst case)
        if (current_distance < closest_distance)    // O(1): assignments
        {
            closest_taxi_id = taxi_id;
            closest_distance = current_distance;
        }
    }
    // O(M): overall loop (average case)
    // O(MN): overall loop (worst case)

    // remove closest taxi from available_taxis
    available_taxis.erase(closest_taxi_id);         // O(1) average; O(M) worst

    // start ride
    Taxi& closest_taxi = taxis.at(closest_taxi_id); // O(1) average; O(N) worst
    closest_taxi.SetRide(source, destination);

    if (closest_taxi.CGetPosition() == station)         // S: # of available taxis at the station
        station_available_taxis.erase(closest_taxi);    // O(log(S))

    // return the closest taxi
    return closest_taxi;

    // all method
    // average: O(M) + O(1) + O(1) + O(log(S)) --> O(M + log(S))
    //                                     since at most S = M, O(M + log(M)) ~ O(M)
    //
    // worst: O(MN) + O(M) + O(N) + O(log(S)) --> O(MN + M + N + log(S)) ~ O(MN + log(S)) ~ O(MN)
}

Taxi CallCenter::CallAtRailStation (const Place& destination)
{
    // return the taxi available at the station that performed the lowest total
    // distance
    if (not station_available_taxis.empty())
    {
        Taxi first_taxi = *(station_available_taxis.begin());

        // set ride
        first_taxi.SetRide(station, destination);
        taxis.at(first_taxi.CGetLicenseId()).SetRide(station, destination);

        station_available_taxis.erase(first_taxi);
        available_taxis.erase(first_taxi.CGetLicenseId());

        return first_taxi;
    } else
    {
        std::cerr << "No available taxis at the station" << std::endl;
        //return Taxi("nonexistent");
        return Call(station, destination);
    }
}

Taxi CallCenter::CallToRailStation (const Place& source)
{
    // return the taxi which is closest to source
    // the ride goes from source to the station
    return Call(source, station);
}

void CallCenter::Arrived (const std::string& license_id)
{
    // get the taxi
    Taxi& taxi = taxis.at(license_id);

    // update the total distance
    std::pair<Place, Place> last_ride = taxi.CGetLastRide();
    float distance = ComputeDistance(last_ride.first, last_ride.second);
    taxi.AddDistance(distance);

    // set the taxi as available
    if (taxi.CGetPosition() == station)
        station_available_taxis.insert(taxi);

    available_taxis.insert(license_id);
}
