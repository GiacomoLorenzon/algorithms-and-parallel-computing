#include "DataFrame.h"

DataFrame::DataFrame (const key_type & c_names)
  : DataFrame ()
{
  /* Your code goes here */
}

DataFrame::DataFrame (void)
  : added_first_column (false), n_rows (0) 
{}

std::vector<DataFrame::key_type>
DataFrame::split (const key_type & s,  char delim) const
{
  key_type word;
  std::vector<key_type> v;
  std::istringstream columns (s);

  while (std::getline (columns, word, delim)) v.push_back (word);

  return v;
}

bool
DataFrame::check_column_name (const key_type & column_name) const
{
    /* Your code goes here */
}

void
DataFrame::set_column_data (const key_type & column_name,
                            const mapped_type & column_data)
{
    /* Your code goes here */
}

DataFrame::mapped_type
DataFrame::get_column (const key_type & column_name) const
{
    /* Your code goes here */
}

double
DataFrame::get_element_at (const key_type & column_name,
                           size_type index) const
{
    /* Your code goes here */
}

void
DataFrame::set_element_at (const key_type & column_name,
                            size_type index, double value)
{
    /* Your code goes here */
}

double
DataFrame::get_mean (const key_type & column_name) const
{
    /* Your code goes here */
}

void
DataFrame::set_column (const key_type & column_name,
                        const mapped_type & column_data)
{
    /* Your code goes here */
}

void
DataFrame::add_column (const key_type & column_name,
                        const mapped_type & column_data)
{
  if (! check_column_name (column_name))
    set_column_data (column_name, column_data);
  else
    std::cerr << "Error, " << column_name
              << " is already included in the DataFrame"
              << std::endl;
}

DataFrame
DataFrame::select_equal (const key_type & c_name,
                          double value) const
{
    /* Your code goes here */
}

void
DataFrame::print (void) const
{
  for (const value_type & element : df_data)
    {
      std::cout << element.first << " :: ";

      for (const double & d : element.second)
        std::cout << d << " ";

      std::cout << std::endl;
    }
}
