//
// Created by Danilo Ardagna on 23/07/21.
//

#include "TimeSeries.h"

bool TimeSeries::date_exist(const std::string & date) const {

    const std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.find(date);
    if (cit_begin == registration_by_date_time.cend())
        return false;
    else
        return true;
}

bool TimeSeries::time_exist(const std::string & time) const {

    const std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_time_date.find(time);
    if (cit_begin == registration_by_time_date.cend())
        return false;
    else
        return true;
}

bool TimeSeries::date_time_exist(const std::string & date, const std::string & time) const{
    if (!date_exist(date))
        return false;

    const std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.find(date);
    // check if timestamp exists
    const std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.find(time);
    if (cinner_it_begin == cit_begin->second.cend())
        return false;

    return true;
}

void TimeSeries::add_registration(const std::string & date, const std::string & time, float value) {
    registration_by_date_time[date][time]= value;
    registration_by_time_date[time][date]= value;
}

float TimeSeries::get_registration(const std::string & date, const std::string & time) const {
    // check if date exists
    if (!date_exist(date))
        return std::numeric_limits<float>::quiet_NaN();

    const std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.find(date);

    // check if timestamp exists
    const std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.find(time);
    // if not return NaN
    if (cinner_it_begin == cit_begin->second.cend())
        return std::numeric_limits<float>::quiet_NaN();
    // else return corresponding value
    return cinner_it_begin->second;
}

float TimeSeries::get_registration_by_date(const std::string & date) const {

    // check if date exists
    if (!date_exist(date))
        return std::numeric_limits<float>::quiet_NaN();

    const std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.find(date);

    std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.cbegin();
    // read sequentially internal map and compute mean
    float sum = 0;
    size_t count =0;
    for (;cinner_it_begin != cit_begin->second.cend(); ++cinner_it_begin){
        sum += cinner_it_begin->second;
        ++count;
    }

    // We are sure that at least one element for the date exists (we cannot add a value
    // associated with a date without specifying a time stamp)
    return sum/count;


}

float TimeSeries::get_registration_by_time(const std::string & time) const {

    // check if time exists
    if (!time_exist(time))
        return std::numeric_limits<float>::quiet_NaN();

    const std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_time_date.find(time);

    std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.cbegin();
    // read sequentially internal map and compute mean
    float sum = 0;
    size_t count =0;
    for (;cinner_it_begin != cit_begin->second.cend(); ++cinner_it_begin){
        sum += cinner_it_begin->second;
        ++count;
    }

    // We are sure that at least one element for the time exists (we cannot add a value
    // associated with a time without specifying a date)
    return sum/count;

}

std::vector<float>
TimeSeries::get_registration_range(const std::string & date1, const std::string & time1, const std::string & date2) const {
    std::vector<float> result;

    if (!date_exist(date1) || date2 < date1)
        return result;

    std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.find(date1);

    while (cit_begin->first < date2 && cit_begin != registration_by_date_time.cend()){
        std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.find(time1);
        while (cinner_it_begin != cit_begin->second.cend()){
            result.push_back(cinner_it_begin->second); // store result
            ++cinner_it_begin; // move to the next time slot if any
        }
        // move to the next day
        ++cit_begin;

    }
    return result;
}

TimeSeries TimeSeries::intersect_time_series(const TimeSeries &ts) const{
    TimeSeries result;

    std::map<std::string,std::map<std::string, float>>::const_iterator cit = ts.registration_by_date_time.cbegin();
    // move to the higher date the iterator
    if (registration_by_date_time.cbegin()->first > cit->first)
        cit = registration_by_date_time.cbegin();
    else
        cit = registration_by_date_time.lower_bound (cit->first);

    // From now on, cit is the iterator to the first level map of the range of interest

    std::map<std::string,std::map<std::string, float>>::const_iterator cit_end = ts.registration_by_date_time.cend();
    --cit_end; // this way cit_end points to the last element of the second time series

    while (cit != registration_by_date_time.cend() and cit->first <= cit_end->first){
        std::map<std::string, float>::const_iterator cinner_it= cit->second.cbegin();
        // cinner_it is the iterator of the second level map
        // cit-> first is the date of the current element
        // cinner_it->first is the time of the current element
        // cinner_it->second is the value of the current element

        // process the current day
        while (cinner_it != cit->second.cend()){
            // if the current element is included also in ts
            if (ts.date_time_exist(cit->first, cinner_it->first))
                // add to the result the mean of the two registrations
                result.add_registration(cit->first, cinner_it->first, (cinner_it->second + ts.get_registration(cit->first, cinner_it->first))/2);
            ++cinner_it; // move to the next registration
        }

        ++cit; // move to the next day
    }

    return result;
}

void TimeSeries::print() const {

    std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.cbegin();

    while (cit_begin != registration_by_date_time.cend()){
        std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.cbegin();
        while (cinner_it_begin != cit_begin->second.cend()){
            std::cout << cit_begin->first << " " <<   cinner_it_begin->first << " " << cinner_it_begin->second << std::endl;
            ++cinner_it_begin; // move to the next time slot if any
        }
        // move to the next day
        ++cit_begin;

    }
}


