#ifndef FCROWN_PROPERTY_HH
#define FCROWN_PROPERTY_HH

#include <string>
#include <fstream>
#include <iostream>
#include <mpi.h>

#include "dense_matrix.hpp"

namespace numeric {

  double fcrown_property (const std::string& filename);

}

#endif /* FCROWN_PROPERTY_HH */