#include "fcrown_property.hpp"

namespace numeric {

  double fcrown_property (const std::string& filename)
  {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // initialize matrix and number of rows/columns
    la::dense_matrix A;
    unsigned n = 0;

    // read matrix from rank 0
    if (rank == 0)
    {
      std::ifstream ifs(filename);
      A.read(ifs);

      n = A.rows();

      A.print(std::cout);
    }

    // broadcast number of rows
    MPI_Bcast(&n, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    // prepare local matrices
    unsigned local_n = n / size;
    la::dense_matrix local_A(local_n, n);

    // scatter
    MPI_Scatter(A.data(), local_n * n, MPI_DOUBLE, 
                local_A.data(), local_n * n, MPI_DOUBLE, 
                0, MPI_COMM_WORLD);

    // sum values on the diagonal and on first and last columns
    double trace = 0.;
    double crown = 0.;
    for (unsigned i = 0; i < local_n; ++i)
    {
      trace += local_A(i, i + rank*local_n);
      crown += (local_A(i,0) + local_A(i,n-1));
    }

    // for the first and last ranks, sum values on the first and last row
    if (rank == 0)
    {
      for (unsigned j = 0; j < n; ++j)
        crown += local_A(0,j);
    }
    if (rank == size - 1)
    {
      for (unsigned j = 0; j < n; ++j)
        crown += local_A(local_n-1,j);
    }

    // allreduce
    MPI_Allreduce(MPI_IN_PLACE, &trace, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(MPI_IN_PLACE, &crown, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    return trace * crown;
  }

}