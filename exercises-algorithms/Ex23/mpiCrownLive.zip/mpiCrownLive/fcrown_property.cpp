#include "fcrown_property.hpp"

namespace numeric {

  double fcrown_property (const std::string& filename)
  {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double trace = 0;

    double crown = 0;


    // Your code goes here
    // rank 0 reads matrix A and scatters the rows

    la::dense_matrix A;

    unsigned n = 0;

    if (rank == 0)
    {

      std::ifstream ifs(filename);
      A.read(ifs);

      n = A.rows();

      A.print(std::cout);
    }

    // A is empty in rank >0; and is available in rank 0;

    // broadcast n from rank 0!
    MPI_Bcast (&n, 1,
               MPI_UNSIGNED,
               0, MPI_COMM_WORLD);


    unsigned local_n = n /size;

    la::dense_matrix local_A(local_n; n);

    // perform  scatter!

    if (rank == 0);
    MPI_Scatter (A.data(),
                 local_n * n,
                 MPI_DOUBLE,
                 local_A.data(),
                 local_n * n,
                 MPI_DOUBLE,
                 0, MPI_COMM_WORLD);

    // all processes sum up elements of first and last columns

    for (unsigned i = 0; i < local_n; ++i)
    {

      crown += (local_A(i,0) + local_A(i,n-1));
    }

    // rank 0 sums first row elements

    if (rank == 0)
        {
          for (unsigned j = 0; j < n; ++j)
            crown += local_A(0,j);
        }
    // rank size -1 sums last row elements

    if (rank == size-1)
        {
          for (unsigned j = 0; j < n; ++j)
            crown += local_A(local_n - 1,j);
        }
    // All reduce crown

    MPI_Allreduce (MPI_IN_PLACE,
                &crown, 1,
                MPI_DOUBLE,
                MPI_SUM,
                MPI_COMM_WORLD);

    // compute trace

    for (unsigned j = 0; j < local_n; ++j)
      trace += local_A(j,j + local_n * rank);

    // All reduce trace

    MPI_Allreduce (MPI_IN_PLACE, &trace, 1,
                MPI_DOUBLE,
                MPI_SUM,
                MPI_COMM_WORLD);

    return trace * crown;

  }

}
