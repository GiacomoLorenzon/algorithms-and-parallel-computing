#include "fcrown_property.hpp"

int main(int argc, char *argv[])
{
  MPI_Init(&argc, &argv);

  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  std::string filename = argv[1];

  double fcrown = numeric::fcrown_property(filename);

  if (rank == 0)
    std::cout << "fcrown_property is: " << fcrown << std::endl;

  MPI_Finalize();

  return 0;
}