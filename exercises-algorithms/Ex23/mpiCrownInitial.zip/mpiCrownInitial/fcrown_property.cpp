#include "fcrown_property.hpp"

namespace numeric {

  double fcrown_property (const std::string& filename)
  {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Your code goes here

  }

}
