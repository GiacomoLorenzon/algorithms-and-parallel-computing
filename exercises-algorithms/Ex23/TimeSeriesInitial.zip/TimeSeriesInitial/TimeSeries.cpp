//
// Created by Danilo Ardagna on 23/07/21.
//

#include "TimeSeries.h"

bool TimeSeries::date_exist(const std::string & date) const {

      // Your code goes here
}

bool TimeSeries::time_exist(const std::string & time) const {

      // Your code goes here
}

bool TimeSeries::date_time_exist(const std::string & date, const std::string & time) const{
      // Your code goes here
}

void TimeSeries::add_registration(const std::string & date, const std::string & time, float value) {
      // Your code goes here
}

float TimeSeries::get_registration(const std::string & date, const std::string & time) const {

      // Your code goes here
}

float TimeSeries::get_registration_by_date(const std::string & date) const {

      // Your code goes here


}

float TimeSeries::get_registration_by_time(const std::string & time) const {

      // Your code goes here

}

std::vector<float>
TimeSeries::get_registration_range(const std::string & date1, const std::string & time1, const std::string & date2) const {
    std::vector<float> result;

      // Your code goes here
}

TimeSeries TimeSeries::intersect_time_series(const TimeSeries &ts) const{
    TimeSeries result;

      // Your code goes here
}

void TimeSeries::print() const {

    std::map<std::string,std::map<std::string, float>>::const_iterator cit_begin = registration_by_date_time.cbegin();

    while (cit_begin != registration_by_date_time.cend()){
        std::map<std::string, float>::const_iterator cinner_it_begin = cit_begin->second.cbegin();
        while (cinner_it_begin != cit_begin->second.cend()){
            std::cout << cit_begin->first << " " <<   cinner_it_begin->first << " " << cinner_it_begin->second << std::endl;
            ++cinner_it_begin; // move to the next time slot if any
        }
        // move to the next day
        ++cit_begin;

    }
}
