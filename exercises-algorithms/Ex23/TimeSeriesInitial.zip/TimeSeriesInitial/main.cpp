#include <iostream>

#include "TimeSeries.h"

int main() {
    TimeSeries exam_day;

    exam_day.add_registration("2021/08/31", "11:30:00", 1);
    exam_day.add_registration("2021/08/31", "11:30:01", 2);
    exam_day.add_registration("2021/08/30", "11:30:00", 1);

    std::cout << exam_day.get_registration("2021/08/31", "11:30:00") << std::endl;
    std::cout << exam_day.get_registration("2021/08/31", "11:30:02") << std::endl;
    std::cout << exam_day.get_registration_by_date("2021/08/31") << std::endl;
    std::cout << exam_day.get_registration_by_date("2021/08/29") << std::endl;
    std::cout << exam_day.get_registration_by_time("11:30:00") << std::endl;

    std::vector<float> result = exam_day.get_registration_range("2021/08/30", "11:30:00", "2021/08/31");
    std::cout << "Vector range:" << std::endl;
    for (auto it = result.cbegin(); it != result.cend(); ++it)
        std::cout << *it << std::endl;

    TimeSeries ts2= exam_day;

    exam_day.add_registration("2021/08/29", "11:30:00", 1);
    std::cout << "Initial time series:" << std::endl;
    exam_day.print();
    TimeSeries result2 = exam_day.intersect_time_series(ts2);
    std::cout << "Intersection result:" << std::endl;
    result2.print();
    return 0;
}
