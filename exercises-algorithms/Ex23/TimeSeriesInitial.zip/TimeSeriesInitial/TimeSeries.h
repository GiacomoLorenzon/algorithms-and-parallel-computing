//
// Created by Danilo Ardagna on 23/07/21.
//

#ifndef TIMESERIES_TIMESERIES_H
#define TIMESERIES_TIMESERIES_H

#include <string>
#include <map>
#include <vector>
#include <limits>
#include <iostream>

class TimeSeries {

    // Your code goes here

public:
    void add_registration(const std::string & date, const std::string & time, float value);
    float get_registration(const std::string & date, const std::string & time) const;
    float get_registration_by_date(const std::string & date) const;
    float get_registration_by_time(const std::string & time) const;
    std::vector<float> get_registration_range(const std::string & date1, const std::string & time1, const std::string & date2) const;
    TimeSeries intersect_time_series(const TimeSeries & ts) const;
    void print() const;

};



#endif //TIMESERIES_TIMESERIES_H
